import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class PraseXml {

	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {
		// TODO Auto-generated method stub
	
	     getabsolutepath get=new getabsolutepath();
		  get. getpath();
		
		//��xml�ļ���ȡΪdocument����
        DocumentBuilder db=DocumentBuilderFactory.newInstance().newDocumentBuilder();
        Document document=db.parse(new File("/Users/pohuahua/Documents/workspace/PraseXml/PRA.xml"));
   
     
        //���ݲ�ͬ�������õ���Ӧ������ֵ
        Element root=document.getDocumentElement() ;
        NodeList list=root.getElementsByTagName("article");
     //  ArrayList<String> files = readFiles(list);
    ArrayList<String> files = parseXML(document);
       System.out.println(files);
	}

	

	public static ArrayList<String> parseXML(Node doc) throws IOException{
		//���doc�������ӽڵ�
		   BufferedWriter bw = new BufferedWriter(new FileWriter(new File("/Users/pohuahua/Documents/workspace/PraseXml/PRA_pacs.txt"),true));
	ArrayList<String> pacscode = new ArrayList<String>();
		NodeList nodes = doc.getChildNodes();
		int article_num=0;
		//���������ӽڵ�
		for(int i=0;i<nodes.getLength();i++){
			Node node1 = nodes.item(i);
		
			//��ýڵ������
			
			String str = node1.getNodeName();
			//�������ڵ���һ��Ԫ�ؽڵ�
			if(node1 instanceof Element){
				// System.out.println(str);
				if(str.equals("article")){
					//��ø�Ԫ�ؽڵ��num����
					
					String doi = ((Element)node1).getAttribute("doi");
					
				// System.out.println(doi);
				 NodeList node1s = node1.getChildNodes();
				 for(int j=0;j<node1s.getLength();j++){
					 Node node2 =node1s.item(j);
					 String str2=node2.getNodeName();
					//	System.out.println(str2+"!!!!!!");
						 if(str2.equals("pacs")){
							 article_num++;
							System.out.println(article_num);
							bw.write(doi+"\t");
							 NodeList node2s = node2.getChildNodes();
							 for(int m=0;m<node1s.getLength();m++){
								 Node node3 =node2s.item(m);
								 if(node3!=null){	
								
								 String str3=node3.getNodeName();
						
							 if(str3.equals("pacscode")){
						//	 System.out.println("!!!!!!!!!!!!!");
							pacscode.add(node3.getTextContent());
							bw.write(node3.getTextContent()+" ");
							
						
							 }
							
								 }
							 }
							 bw.newLine();	 
						}
				 }
					
			}

			parseXML(node1);
		}
		}
		bw.close();

	return pacscode;
	
	}
}
