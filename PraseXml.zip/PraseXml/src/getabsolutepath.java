import java.io.File;
import java.io.IOException;

public class getabsolutepath {
	public void getpath() throws IOException{
	File directory = new File("a.txt");
	File f = new File("b.java"); 
	 f.createNewFile();

	 String s =f.getAbsolutePath();
	
	 System.out.println(s); 
	}
}
