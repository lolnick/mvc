package Jsphhh;
import java.io.File;
import java.io.IOException;
import java.net.URL;  
import java.net.URLClassLoader;  
import javax.servlet.Servlet;  
import javax.servlet.ServletRequest;  
import javax.servlet.ServletResponse;

import Jsphhh.changeJsp;  
  
public class ServletProcessor
{  
    public void process(Request request, Response response)  
    {  
    	//锟矫碉拷路锟斤拷锟斤拷锟斤拷取锟斤拷锟斤拷应servlet锟斤拷锟�
        String uri = request.getUri();  
        String servletname = uri.substring(uri.lastIndexOf("/") + 1);  
        URLClassLoader loader = null;
        try  
        {  
            //锟斤拷锟斤拷路锟斤拷锟斤拷锟斤拷应锟斤拷锟斤拷锟�
            URL[] urls = new URL[1];  
            File classPath = new File(System.getProperty("user.dir") + File.separator + "src" + File.separator);
            //锟斤拷锟斤拷锟斤拷路锟斤拷转为锟斤拷应锟斤拷式
            URL url = classPath.toURI().toURL();
            urls[0]=url;
            //锟斤拷锟截革拷路锟斤拷
            loader = new URLClassLoader(urls);  
        }  
        catch (IOException e)  
        {  
            System.out.println(e.toString());  
        }  
        Class<?> myClass = null; 
        try  
        {  
            //锟斤拷锟斤拷锟斤拷应路锟斤拷锟铰碉拷锟斤拷应锟斤拷  
            myClass = loader.loadClass(readx.getPath(servletname));  
        }  
        catch (ClassNotFoundException e)  
        {  
            System.out.println(e.toString());  
        }  
        Servlet servlet = null;  
        try  
        {  
            //锟斤拷锟斤拷锟斤拷应锟斤拷锟洁并实锟斤拷然锟斤拷锟斤拷锟絪ervlet锟斤拷init,service锟斤拷锟斤拷锟斤拷  
            servlet = (Servlet) myClass.newInstance();
            servlet.service((ServletRequest) request, (ServletResponse) response);
        }  
        catch (Exception e)  
        {  
            System.out.println(e.toString());  
        }  
        catch (Throwable e)  
        {  
            System.out.println(e.toString());  
        }  
    }  
    
    public void process2(Request request, Response response)  
    {  
    	//锟矫碉拷路锟斤拷锟斤拷锟斤拷取锟斤拷锟斤拷应jsp锟斤拷锟�
        String uri = request.getUri();  
        String jspname = uri.substring(uri.lastIndexOf("/") + 1);
        String[] names = jspname.split("\\.");
        File file = new File(System.getProperty("user.dir") + File.separator + "WebRoot" + File.separator + jspname);
        
        //锟斤拷jsp锟侥硷拷锟斤拷锟斤拷时转锟斤拷为servlet锟侥硷拷
        if(file.exists()){
        	try {
				changeJsp.readFile(jspname);
			} catch (IOException e) {
				// TODO 锟皆讹拷锟斤拷傻锟� catch 锟斤拷
				e.printStackTrace();
			}
        }else{
        	//锟揭诧拷锟斤拷锟侥硷拷时锟斤拷锟斤拷404锟斤拷息
        	String errorMessage = "HTTP/1.1 404 File Not Found\r\n" + "Content-Type: text/html\r\n" + "Content-Length: 23\r\n" + "\r\n" + "<h1>File Not Found</h1>";  
            try {
				response.output.write(errorMessage.getBytes());
			} catch (IOException e1) {
				// TODO 锟皆讹拷锟斤拷傻锟� catch 锟斤拷
				e1.printStackTrace();
			}
            return; 
        }

		File jsp1 = new File(System.getProperty("user.dir") + File.separator 
    			+ "bin" + File.separator + "Jsphhh" + File.separator + names[0] + "_jsp.class");
		while(!jsp1.exists()){}
		
		File jsp2 = new File(System.getProperty("user.dir") + File.separator 
    			+ "src" + File.separator + "Jsphhh" + File.separator + names[0] + "_jsp.java");
		while(!jsp2.exists()){}
		
        URLClassLoader loader = null;
        try  
        {  
            //锟斤拷锟斤拷路锟斤拷锟斤拷锟斤拷应锟斤拷锟斤拷锟�
            URL[] urls = new URL[1];  
            File classPath = new File(System.getProperty("user.dir") + File.separator + "src" + File.separator);
            //锟斤拷锟斤拷锟斤拷路锟斤拷转为锟斤拷应锟斤拷式
            URL url = classPath.toURI().toURL();
            urls[0]=url;
            //锟斤拷锟截革拷路锟斤拷
            loader = new URLClassLoader(urls);  
        }  
        catch (IOException e)  
        {  
            System.out.println(e.toString());  
        }  
        Class<?> myClass = null; 
        try  
        {
            //锟斤拷锟斤拷锟斤拷应路锟斤拷锟铰碉拷锟斤拷应锟斤拷  
            myClass = loader.loadClass("Jsphhh." + names[0] + "_jsp");
        }  
        catch (ClassNotFoundException e)  
        {  
        	//锟洁不锟斤拷锟斤拷锟斤拷锟绞憋拷锟斤拷锟�404锟斤拷息
            String errorMessage = "HTTP/1.1 404 File Not Found\r\n" + "Content-Type: text/html\r\n" + "Content-Length: 23\r\n" + "\r\n" + "<h1>File Not Found</h1>";  
            try {
				response.output.write(errorMessage.getBytes());
			} catch (IOException e1) {
				// TODO 锟皆讹拷锟斤拷傻锟� catch 锟斤拷
				e1.printStackTrace();
			}
            return; 
        }  
        Servlet servlet = null;  
        try  
        {  
            //锟斤拷锟斤拷锟斤拷应锟斤拷锟洁并实锟斤拷然锟斤拷锟斤拷锟絪ervlet锟斤拷init,service锟斤拷锟斤拷锟斤拷  
            servlet = (Servlet) myClass.newInstance();
            servlet.service((ServletRequest) request, (ServletResponse) response);
        }  
        catch (Exception e)  
        {  
            System.out.println(e.toString());  
        }  
        catch (Throwable e)  
        {  
            System.out.println(e.toString());  
        }  
    }  
    
    public void process3(Request request, Response response, String jspname)  
    {
		File jsp1 = new File(System.getProperty("user.dir") + File.separator 
    			+ "bin" + File.separator + "Jsphhh" + File.separator + jspname + "_jsp.class");
		while(!jsp1.exists()){}
		
		File jsp2 = new File(System.getProperty("user.dir") + File.separator 
    			+ "src" + File.separator + "Jsphhh" + File.separator + jspname + "_jsp.java");
		while(!jsp2.exists()){}
		
        URLClassLoader loader = null;
        try  
        {  
            //锟斤拷锟斤拷路锟斤拷锟斤拷锟斤拷应锟斤拷锟斤拷锟�
            URL[] urls = new URL[1];  
            File classPath = new File(System.getProperty("user.dir") + File.separator + "src" + File.separator);
            //锟斤拷锟斤拷锟斤拷路锟斤拷转为锟斤拷应锟斤拷式
            URL url = classPath.toURI().toURL();
            urls[0]=url;
            //锟斤拷锟截革拷路锟斤拷
            loader = new URLClassLoader(urls);  
        }  
        catch (IOException e)  
        {  
            System.out.println(e.toString());  
        }  
        Class<?> myClass = null; 
        try  
        {
            //锟斤拷锟斤拷锟斤拷应路锟斤拷锟铰碉拷锟斤拷应锟斤拷  
            myClass = loader.loadClass("Jsphhh." + jspname + "_jsp");
        }  
        catch (ClassNotFoundException e)  
        {
            String errorMessage = "HTTP/1.1 404 File Not Found\r\n" + "Content-Type: text/html\r\n" + "Content-Length: 23\r\n" + "\r\n" + "<h1>File Not Found</h1>";  
            try {
				response.output.write(errorMessage.getBytes());
			} catch (IOException e1) {
				// TODO 锟皆讹拷锟斤拷傻锟� catch 锟斤拷
				e1.printStackTrace();
			}
            return; 
        } finally{
        	if(jsp1.exists()){
        		jsp1.delete();
        	}
        	if(jsp2.exists()){
        		jsp2.delete();
        	}
        }
        Servlet servlet = null;  
        try  
        {  
            //锟斤拷锟斤拷锟斤拷应锟斤拷锟洁并实锟斤拷然锟斤拷锟斤拷锟絪ervlet锟斤拷init,service锟斤拷锟斤拷锟斤拷  
            servlet = (Servlet) myClass.newInstance();
            servlet.service((ServletRequest) request, (ServletResponse) response);
        }  
        catch (Exception e)  
        {  
            System.out.println(e.toString());  
        }
    }  

}  