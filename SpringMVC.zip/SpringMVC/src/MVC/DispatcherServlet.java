package MVC;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.LinkedList;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import Jsphhh.Request;
import Jsphhh.Response;
import Jsphhh.ServletProcessor;
import Jsphhh.StaticResourceProcessor;
import Jsphhh.changeJsp;
import Jsphhh.readx;
import test.test;

public class DispatcherServlet implements Servlet {

	private Map<String, Method> r = new ConcurrentHashMap<String, Method>();
	private test atest;

	public void setR(Map<String, Method> r) {
		this.r = r;
	}
	public void setest(test test) {
		this.atest = test;
	}
	
	public void service(Request request, Response response) throws ServletException, IOException {
		// TODO 鑷姩鐢熸垚鐨勬柟娉曞瓨鏍�
        String uri = request.getUri();
        boolean flag = false;
        try{
        	if(uri.substring(uri.length()-4).equals(".jsp")){
        		flag = true;
        	}
        } catch(Exception e){}
        String key = uri.substring(uri.lastIndexOf("/"));
        
        Method amethod = r.get(key);
    	ModelAndView mav2 = null;
        if(amethod != null){
        	ModelAndView mav = new ModelAndView();
        	LinkedList<String[]> datas = request.getParameters();
        	for(int i=0;i<datas.size();i++){
        		mav.setMap(datas.get(i)[0], datas.get(i)[1]);
        	}
        	Method method = r.get(key);
        	try {
        		mav2 = (ModelAndView) method.invoke(atest, mav);
			} catch (Exception e) {
				// TODO 鑷姩鐢熸垚鐨� catch 鍧�
				e.printStackTrace();
			}
        	String filename = changeJsp.testJsp(mav2.getViewName()+".jsp", mav2);
        	ServletProcessor processor = new ServletProcessor();
            processor.process3(request, response, filename);
        }
        //鍒ゆ柇璇锋眰鏄惁涓簊ervlet 
        else if (readx.ifServlet(uri))  
        {
        	//杩斿洖servlet缃戦〉
            ServletProcessor processor = new ServletProcessor();  
            processor.process(request, response);  
        }  
        else if(flag)
        {
        	//杩斿洖涓�涓浐瀹氱綉椤�
        	ServletProcessor processor = new ServletProcessor();  
            processor.process2(request, response);  
        }  
        else
        {
        	//杩斿洖涓�涓浐瀹氱綉椤�
            StaticResourceProcessor processor = new StaticResourceProcessor();  
            processor.process(request, response);  
        } 
		
	}
	
	@Override
	public void init(ServletConfig arg0) throws ServletException {
	}

	@Override
	public void destroy() {
		// TODO 鑷姩鐢熸垚鐨勬柟娉曞瓨鏍�
		
	}

	@Override
	public ServletConfig getServletConfig() {
		// TODO 鑷姩鐢熸垚鐨勬柟娉曞瓨鏍�
		return null;
	}

	@Override
	public String getServletInfo() {
		// TODO 鑷姩鐢熸垚鐨勬柟娉曞瓨鏍�
		return null;
	}

	@Override
	public void service(ServletRequest arg0, ServletResponse arg1) throws ServletException, IOException {
		// TODO 鑷姩鐢熸垚鐨勬柟娉曞瓨鏍�
		
	}

}
