package MVC;

import java.util.HashMap;
import java.util.Map;

public class ModelAndView {

	private String viewName;
	private Map<String, Object> paras = new HashMap<String, Object>();
	private Map<String, String> model = new HashMap<String, String>();
	
	public String getViewName() {
		return viewName;
	}

	public void setViewName(String viewName) {
		this.viewName = viewName;
	}

	public void addObject(String name, Object object) {
		paras.put(name, object);
	}

	public Object getObject(String key) {
		return paras.get(key);
	}

	public Object getMap(String key) {
		return model.get(key);
	}

	public void setMap(String key, String value) {
		model.put(key, value);
	}
	
}
