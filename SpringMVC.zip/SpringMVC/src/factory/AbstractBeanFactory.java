package factory;

import java.lang.reflect.Method;
import java.util.LinkedList;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import bean.BeanDefinition;

public abstract class AbstractBeanFactory implements BeanFactory{
	private Map<String, BeanDefinition> beanDefinitionMap = new ConcurrentHashMap<String, BeanDefinition>();
	private Map<String, Method> requestMap = new ConcurrentHashMap<String, Method>();


	public Object getBean(String beanName)
	{
	   //   System.out.println(beanDefinitionMap);
			return this.beanDefinitionMap.get(beanName).getBean();
		
	}
	
	public void registerBeanDefinition(String beanName, BeanDefinition beanDefinition)
	{
		beanDefinition = GetCreatedBean(beanDefinition);
		this.beanDefinitionMap.put(beanName, beanDefinition);
	}
	public void registerRequest(String requestName, Method method)
	{
		this.requestMap.put(requestName, method);
	}
	
	public Map<String, Method> getRequests()
	{
		return requestMap;
	}

	protected abstract BeanDefinition GetCreatedBean(BeanDefinition beanDefinition);
}
